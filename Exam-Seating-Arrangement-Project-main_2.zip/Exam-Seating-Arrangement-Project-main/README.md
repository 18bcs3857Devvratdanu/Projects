# Exam-Seating-Arrangement-Project
To simplify examination hall allotment and seating arrangement for the student, an web application for automatic seating arrangement is developed. 

Project Developed By :- 
-> PARAS [UID - 18BCS3849]
-> HARSHIL DHIMAN [UID - 18BCS3843]
-> DEVVRAT DANU [UID - 18BCS3857]
-> VANSHIKA SOOD [UID - 18BCS3799]
