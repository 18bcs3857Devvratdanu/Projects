 <?php 
 include('connect.php');

 ?>

 
        <div class="left-sidebar">
            
            <div class="scroll-sidebar">
                
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a href="student_panel.php" aria-expanded="false"><i class="fa fa-window-maximize"></i>Dashboard</a>
                        </li>              
                    </ul>   
                </nav>
                




            </div>
           
        </div>
        